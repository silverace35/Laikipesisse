<section class="idee" >
    <div class="titreIdeeMoment">
        <h1>Découvrez l'idée du moment</h1>
    </div>
    <div class="goldenStar">
       <a href="#5" title="Donner 5 étoiles">☆</a>
       <a href="#4" title="Donner 4 étoiles">☆</a>
       <a href="#3" title="Donner 3 étoiles">☆</a>
       <a href="#2" title="Donner 2 étoiles">☆</a>
       <a href="#1" title="Donner 1 étoile">☆</a>
    </div>