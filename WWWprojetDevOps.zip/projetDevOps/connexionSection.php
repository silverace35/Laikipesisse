<section>
    <h1>Connexion</h1>
</section>
<div class="connex">
    <section class="connexion">
        <h1>connexion</h1>
        <form method="post" action="#">
            <input type="name" id="identifiant" name="identifiant" placeholder="Identifiant"/>
            <input type="password" id="mdp" name="mdp" placeholder="Mot de passe"/>
            <button type="submit">se connecter</button>
        </form>
    </section>
</div>