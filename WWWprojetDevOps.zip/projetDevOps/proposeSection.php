<section class="proposition">
    <div>
        <h1>Proposer une idée</h1>
        <form method="post" action="#" enctype="multipart/form-data">
            <label for="marque">Nom de la marque</label>
            <input type="text" id="marque" name="marque" />
            <label for="description">Description de l'idée</label>
            <textarea id="description" name="description">
            </textarea> 
            <label for="image">Charger une image
                <input type="file" name="image" id="image"/></label>
            <button type="submit">Envoyer</button>
        </form>
    </div>    
</section>