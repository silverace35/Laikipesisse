<?php
    require('header.php');
    require('nosIdeesSection.php');
    require('footer.php');
?>