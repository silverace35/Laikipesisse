        <footer>
            <div>
            <p>BobArt©2018</p>
            </div>
            <div>
                <a href="ideeDuMoment.html">L'idée du moment</a>
                <a href="nosIdees.html">Nos idées</a>
                <a href="propose.html">Proposer une idée</a>
            </div>
        </footer>
    </body>
</html>