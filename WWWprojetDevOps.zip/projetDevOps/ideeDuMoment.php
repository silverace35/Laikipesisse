<?php
    require('header.php');
    require('ideeDMSection1.php');
    require('ideeDMSection2.php');
    require('footer.php');
?>
