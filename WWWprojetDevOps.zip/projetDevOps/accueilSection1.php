<section class="accueil">
    <div>
        <h1>Bienvenue sur Bobart !</h1>
        <p>BobArt est née il y a plus de 20 ans de l'association des meilleurs graphistes de Bretagne, nous sommes une équipe qui s'engage dans la quête du Saint Graal des marketeurs : toucher la bonne personne, au bon moment et avec le bon message. Nous pronons la liberté des idées afin de laisser cours à l'imagination de nos graphistes. Chez BobArt nous sommes sérieux sans se prendre au sérieux... 
        </p>
        <img src="img/agence_rennes.jpg" alt="ville" title="ville"/>
    </div>
</section>