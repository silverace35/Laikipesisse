<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <title>Accueil-BobArt</title>
        <link href="css/styles.css" rel="stylesheet"/>
        <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
        <meta name="autor" content="Laikipesisse"/>
    </head>
    <body>
<!----------------- Header du site internet-------------------------->  <header>
        <nav>
            <a href="Accueil.html"><img src="img/logo%20bobart.png" alt="logo BobArt"/></a>
            <div class="menu">
                <a href="ideeDuMoment.html">L'idée du moment</a>
                <a href="nosIdees.html">Nos idées</a>
                <a href="propose.html">Proposer une idée</a>
            </div>
            <div class="cnx_ins">
                <a href="connexion.html">Se connecter</a>
            </div>
        </nav>
    </header>