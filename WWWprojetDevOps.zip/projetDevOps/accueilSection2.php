<section class="locaux">
    <div>
        <div class="image">
            <img src="img/locaux%20high%20tech.jpg" alt="2ème image accueil"/>
        </div>
        <div class="texte">
            <article>
                <p>
                Vous avez une idée de projet ? Vous voulez l'avoir pour dans 2 semaines ? Et bien chez BobArt à la place de 2 semaines nous vous le livrons dans 14 jours.</p>
                <img src="https://img.icons8.com/ios/50/000000/calendar.png"/>
                <p>Envie de nous aider dans notre développement ? Nous acceptons les payements et donation en cartes bleues, paypal, liquide ou encore nature.</p>
                <img src="https://img.icons8.com/ios/50/000000/bank-cards.png"/>
            </article>
            <article>
                <p>Nous sommes une équipe qui se renouvelle continuellement, nous changeons de méthodes et d'employés tout les 3 mois afin d'avoir un roulement de créativité.</p>
                <img src="https://img.icons8.com/ios/50/000000/rotate-filled.png">
                <p>Nous avons connus une forte croissance récemment : BobArt l'agence de publicité qui se développe encore plus rapidement que l'herpès.</p>
                <img src="https://img.icons8.com/ios/50/000000/positive-dynamic.png">
            </article>
        </div>
    </div>    
</section>