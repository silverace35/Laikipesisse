<?php
    require('header.php');
    require('accueilSection1.php');
    require('accueilSection2.php');
    require('footer.php');
?>