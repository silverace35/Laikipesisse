<section class="banniere">
                <h1>Découvrez les différentes idées !</h1>
        </section>
        <section class="idees">
            <div>
                <article>
                    <div class="img0">
                        <img src="img/Spiderman.jpg" alt="#" title="#"/>
                    </div>
                    <div class="text0">
                        <h2>Super Raid</h2>
                        <div class="rating">
                           <a href="#5" title="Donner 5 étoiles">☆</a>
                           <a href="#4" title="Donner 4 étoiles">☆</a>
                           <a href="#3" title="Donner 3 étoiles">☆</a>
                           <a href="#2" title="Donner 2 étoiles">☆</a>
                           <a href="#1" title="Donner 1 étoile">☆</a>
                        </div>      
                        <a>Notez cette idée !</a>
                        <p>Vous en avez marre des insectes volants ou rampants ? Vous passez vos nuits à essayer de survivre aux moustiques ? Des super-héros en collant moulant rouge et noir veulent vous "sauver" ? Avec le nouveau produit Super-Raid vous n'aurez plus aucun soucis."</p>
                    </div>      
                </article>
                <article>
                    <div class="img0">
                        <img src="img/rillettes.jpg" alt="#" title="#"/>
                    </div>
                    <div class="text0">
                        <h2>Rillettes Bordeau Chenil</h2>
                        <div class="rating">
                           <a href="#5" title="Donner 5 étoiles">☆</a>
                           <a href="#4" title="Donner 4 étoiles">☆</a>
                           <a href="#3" title="Donner 3 étoiles">☆</a>
                           <a href="#2" title="Donner 2 étoiles">☆</a>
                           <a href="#1" title="Donner 1 étoile">☆</a>
                        </div>
                        <a>Notez cette idée !</a>
                        <p>Les rillettes produit français connu tous, vous avez surrement en tête le goùt de nos rillettes de porcs d'oies ou encore de cheval (manger à votre insu). Nous avons donc élaborer un nouveau produit de fête en coopération avec l'usine de production Cruella d'enfer : les rillettes de chien bordeau chenil.</p>
                    </div>    
                </article>
                <article>
                    <div class="img0">
                        <img src="img/aiephone.jpg" alt="#" title="#"/>
                    </div>
                    <div class="text0">
                        <h2>aiePhone</h2>
                        <div class="rating">
                           <a href="#5" title="Donner 5 étoiles">☆</a>
                           <a href="#4" title="Donner 4 étoiles">☆</a>
                           <a href="#3" title="Donner 3 étoiles">☆</a>
                           <a href="#2" title="Donner 2 étoiles">☆</a>
                           <a href="#1" title="Donner 1 étoile">☆</a>
                        </div>
                        <a>Notez cette idée !</a>
                        <p>An de grâce 2018, le 5ème aiePhone sort en ce mois de décembre. Malgrès le fait que 3 autres sont sortis cette année, vous ne pouvez vous empêcher de l'acheter. Vous vous sentez attirer par ce produit et sa plus grosse nouveauté : les boutons pour monter et descendre le volume sonore ne sont plus des + et - mais des x et ÷. Cette nouveauté s'apprete à révolutionner le marché mobile. De plus ce produit est disponible à un prix très attractif de seulement 1130€, ne cherchez plus de cadeau pour noël : vous l'avez trouvé !</p>
                        </div>    
                </article>
                <article>
                    <div class="img0">
                        <img src="img/parfum.png" alt="#" title="#"/>
                    </div>
                    <div class="text0">
                        <h2>Sueur de mâle</h2>
                        <div class="rating">
                           <a href="#5" title="Donner 5 étoiles">☆</a>
                           <a href="#4" title="Donner 4 étoiles">☆</a>
                           <a href="#3" title="Donner 3 étoiles">☆</a>
                           <a href="#2" title="Donner 2 étoiles">☆</a>
                           <a href="#1" title="Donner 1 étoile">☆</a>
                        </div>
                        <a>Notez cette idée !</a>
                        <p>Vous êtes faibles ! Vous sentez la défaite ! Rien n'est définitif vous pouvez encore changer ! Dans nos laboratoires, nos scientifiques ont mis au point un parfum à base de sueur d'hommes viriles. Les femmes ne vous dirons plus jamais non grâce au parfum sueur de mâle !</p>
                    </div>    
                </article>
            </div>
        </section>