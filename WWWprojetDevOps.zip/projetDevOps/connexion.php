<?php
    require('header.php');
    require('connexionSection.php');
    require('footer.php')
?>