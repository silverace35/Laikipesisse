<img  class="imageIdeeDuMoment" src="img/aiephone.jpg" alt="publicité incroyablement smoothie"/>
    <article class=ideeMoment>
        <h2>L'idée du moment</h2>
        <p>
            An de grâce 2018, le 5ème aiePhone sort en ce mois de décembre. Malgrès le fait que 3 autres sont sortis cette année, vous ne pouvez vous empêcher de l'acheter. Vous vous sentez attirer par ce produit et sa plus grosse nouveauté : les boutons pour monter et descendre le volume sonore ne sont plus des + et - mais des x et ÷. Cette nouveauté s'apprete à révolutionner le marché mobile. De plus ce produit est disponible à un prix très attractif de seulement 1130€, ne cherchez plus de cadeau pour noël : vous l'avez trouvé !
        </p>
    </article>
</section>