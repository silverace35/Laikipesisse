<?php
    require('header.php');
    require('proposeSection.php');
    require('footer.php');
?>